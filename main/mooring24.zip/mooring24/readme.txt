Mooring Design and Dynamics

This is a MATLAB application. You must have an installed version of Matlab V5.X
You should have two files: mdd.zip (or mdd.tar.Z for UNIX) and
mdddoc.zip (or mdddoc.tar.Z).

Programs (mdd.zip or mdd.tar.Z)

Un-compress/zip all program files in this (mdd.zip) archive into a Matlab subdirectory (such as)
/matlab/toolbox/local/mdd
Add this directory to your path within Matlab.
Start the program be typing "moordesign" at the Matlab command prompt.

Ducumentation/Users Guide  (mdddoc.zip or mdddoc.tar.Z)

Un-compress/zip the mdddoc.zip archive files into a Matlab subdirectory (such as)
/matlab/help/toolbox/mdd
Then from the Matlab command prompt, type "mdd".
Alternatively, start your web browser, and make/save a link to the file "mdd.html" in this subdirectory.

If you are using an older version of Matlab (pre-v7 R14), then your mat files are uncompressed. The latest versions
compress data mat files, and you will need the v6 of the basic mat files mdcodes.mat and mmposition.mat

Comments: rdewey@uvic.ca
