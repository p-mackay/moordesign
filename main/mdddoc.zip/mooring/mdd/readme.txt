MD&D Users Guide Installation

Un-zip (or un-compress) the entire contents of the mdddoc.zip (mdddoc.tar.Z) 
into the MATLAB help directory:

/matlab/help/toolbox/mdd/

Then, from the MATLAB command prompt, you should be able to simply type:

>>mdd

and the Users Guide should automatically load into your computers web browser.

